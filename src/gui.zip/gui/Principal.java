/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gui;

import acceso.Conexion;

/**
 *
 * @author ksant
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Conexion conexion = new Conexion();
        conexion.conectar();
        PantallaPrincipal vista = new PantallaPrincipal();
        vista.setVisible(true);
        
        
        
    }
    
}
